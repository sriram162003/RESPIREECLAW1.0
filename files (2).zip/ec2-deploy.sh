#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# RespireeClaw Gateway — EC2 Amazon Linux Setup & Deploy Script
# Works on Amazon Linux 2 and Amazon Linux 2023 (AL2023)
# Run as ec2-user after SSH-ing in:
#   bash ec2-deploy.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

echo ""
echo "=============================================="
echo "  RespireeClaw Gateway — EC2 Setup & Deploy"
echo "=============================================="
echo ""

# ── 1. Detect Amazon Linux version ────────────────────────────────────────────
if grep -q "Amazon Linux 2023" /etc/os-release 2>/dev/null; then
  AL_VERSION=2023
  PKG_MGR="dnf"
else
  AL_VERSION=2
  PKG_MGR="yum"
fi
echo "[1/6] Detected Amazon Linux $AL_VERSION (using $PKG_MGR)"

# ── 2. Install Docker ──────────────────────────────────────────────────────────
echo "[2/6] Installing Docker..."
sudo $PKG_MGR update -y -q

if [ "$AL_VERSION" = "2023" ]; then
  sudo $PKG_MGR install -y docker
else
  # AL2 ships docker in the standard repo
  sudo $PKG_MGR install -y docker
fi

sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker ec2-user
echo "      Docker installed and enabled."

# ── 3. Install Docker Compose v2 plugin ───────────────────────────────────────
echo "[3/6] Installing Docker Compose v2..."
COMPOSE_DIR="/usr/local/lib/docker/cli-plugins"
sudo mkdir -p "$COMPOSE_DIR"

# Detect architecture (x86_64 or aarch64/arm64)
ARCH=$(uname -m)
if [ "$ARCH" = "aarch64" ]; then
  COMPOSE_BIN="docker-compose-linux-aarch64"
else
  COMPOSE_BIN="docker-compose-linux-x86_64"
fi

COMPOSE_URL="https://github.com/docker/compose/releases/latest/download/$COMPOSE_BIN"
sudo curl -fsSL "$COMPOSE_URL" -o "$COMPOSE_DIR/docker-compose"
sudo chmod +x "$COMPOSE_DIR/docker-compose"
echo "      Docker Compose installed."

# ── 4. Upload / unzip the project ─────────────────────────────────────────────
echo "[4/6] Preparing project directory..."
PROJECT_DIR="$HOME/respireeclaw"

if [ -d "$PROJECT_DIR" ]; then
  echo "      $PROJECT_DIR already exists — skipping unzip."
else
  # Detect zip name (supports the fixed zip or any renamed version)
  ZIP_FILE=$(ls ~/respireeclaw*.zip 2>/dev/null | head -1 || true)
  if [ -z "$ZIP_FILE" ]; then
    echo ""
    echo "  ERROR: No respireeclaw*.zip found in your home directory."
    echo "  Upload it first with:"
    echo "    scp -i your-key.pem respireeclaw-gateway-v1_0_1-fixed.zip ec2-user@<ip>:~"
    exit 1
  fi
  echo "      Found $ZIP_FILE — unzipping..."
  sudo $PKG_MGR install -y unzip -q
  unzip -q "$ZIP_FILE" -d "$HOME"
  # The zip contains a project_fixed sub-folder
  mv "$HOME"/*/project_fixed "$PROJECT_DIR" 2>/dev/null || \
    mv "$HOME"/project_fixed "$PROJECT_DIR" 2>/dev/null || true
  echo "      Project extracted to $PROJECT_DIR"
fi

# ── 5. Drop the fixed deploy files into the project ───────────────────────────
echo "[5/6] Installing fixed deploy files..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

for f in Dockerfile docker-compose.yml .dockerignore aura-config.yaml; do
  if [ -f "$SCRIPT_DIR/$f" ]; then
    cp "$SCRIPT_DIR/$f" "$PROJECT_DIR/$f"
    echo "      Copied $f"
  else
    echo "      WARNING: $f not found next to this script — skipping."
  fi
done

# ── 6. Create .env if missing ──────────────────────────────────────────────────
echo "[6/6] Checking .env..."
if [ ! -f "$PROJECT_DIR/.env" ]; then
  cp "$PROJECT_DIR/.env.example" "$PROJECT_DIR/.env"
  echo ""
  echo "  ⚠️  .env created from .env.example."
  echo "  You MUST edit it and add at least one LLM API key before starting:"
  echo ""
  echo "      nano $PROJECT_DIR/.env"
  echo ""
  echo "  Minimum required (pick one):"
  echo "    ANTHROPIC_API_KEY=sk-ant-..."
  echo "    OPENAI_API_KEY=sk-..."
  echo ""
  echo "  Then run:  cd $PROJECT_DIR && docker compose up -d --build"
  exit 0
else
  echo "      .env already exists."
fi

# ── Build & Start ──────────────────────────────────────────────────────────────
echo ""
echo "=============================================="
echo "  Building and starting RespireeClaw..."
echo "  (first build takes 5–10 minutes)"
echo "=============================================="
echo ""

# Apply docker group without requiring logout — newgrp trick via sg
cd "$PROJECT_DIR"
sg docker -c "docker compose up -d --build"

echo ""
echo "=============================================="
echo "  ✅  RespireeClaw is running!"
echo "=============================================="
echo ""
echo "  Webchat UI : http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || echo '<EC2-public-IP>'):3000"
echo "  REST API   : http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || echo '<EC2-public-IP>'):3002/api/health"
echo ""
echo "  Useful commands:"
echo "    docker compose logs -f        # live logs"
echo "    docker compose ps             # container status"
echo "    docker compose down           # stop"
echo "    docker compose up -d --build  # rebuild after changes"
echo ""
echo "  ⚠️  EC2 Security Group: make sure ports 3000, 3001, 3002 are open"
echo "     (or put a reverse proxy / ALB in front for HTTPS)"
echo ""
