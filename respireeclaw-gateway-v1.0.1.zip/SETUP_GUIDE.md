# RespireeClaw on Amazon Linux EC2 — Setup Guide

## 1. Launch & connect to your EC2 instance

Use Amazon Linux 2023 (or AL2). SSH in:
```bash
ssh -i your-key.pem ec2-user@<your-ec2-public-ip>
```

---

## 2. Install Docker & Docker Compose

```bash
sudo yum update -y

# Install Docker
sudo yum install -y docker
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker ec2-user

# Install Docker Compose v2 plugin
sudo mkdir -p /usr/local/lib/docker/cli-plugins
sudo curl -SL https://github.com/docker/compose/releases/latest/download/docker-compose-linux-x86_64 \
  -o /usr/local/lib/docker/cli-plugins/docker-compose
sudo chmod +x /usr/local/lib/docker/cli-plugins/docker-compose

# Log out and back in so the docker group takes effect
exit
```

Re-SSH, then verify:
```bash
docker --version
docker compose version
```

---

## 3. Upload the project to EC2

**Option A — from your local machine:**
```bash
scp -i your-key.pem respireeclaw-master.zip ec2-user@<ec2-ip>:~
ssh -i your-key.pem ec2-user@<ec2-ip>
unzip respireeclaw-master.zip
mv respireeclaw-master respireeclaw
cd respireeclaw
```

**Option B — clone from GitHub (if repo is public):**
```bash
sudo yum install -y git
git clone https://github.com/sriram162003/respireeclaw.git
cd respireeclaw
```

---

## 4. Copy the Dockerfile & docker-compose.yml into the project folder

```bash
# Upload the two files you downloaded, OR paste their contents directly:
nano Dockerfile          # paste the Dockerfile content, save with Ctrl+O
nano docker-compose.yml  # paste the docker-compose content, save with Ctrl+O
```

---

## 5. Create your .env file

```bash
cp .env.example .env
nano .env
```

Fill in at minimum one LLM key. Example for Claude:
```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxx
```

Add any channel tokens you want (Telegram, Slack, Discord, etc.).

---

## 6. Open the required port in your EC2 Security Group

In the AWS Console → EC2 → Security Groups → your instance's group:
- Add **Inbound rule**: Type = Custom TCP, Port = **3000**, Source = your IP (or 0.0.0.0/0 for public)

---

## 7. Build and start the container

```bash
# First-time build (takes 5–10 min due to native modules & Playwright)
docker compose build

# Start in the background
docker compose up -d
```

---

## 8. Run first-time onboarding (creates ~/.aura config)

```bash
docker compose exec respireeclaw node agent.js onboard
```

Follow the interactive prompts to set up your agent name, LLM, and channels.

---

## 9. Verify everything is running

```bash
# Check container is up
docker compose ps

# Tail logs
docker compose logs -f

# Check status inside container
docker compose exec respireeclaw node agent.js status
```

Visit: `http://<your-ec2-public-ip>:3000`

---

## Useful Commands

| Action | Command |
|--------|---------|
| Start | `docker compose up -d` |
| Stop | `docker compose down` |
| Restart | `docker compose restart` |
| View logs | `docker compose logs -f` |
| Rebuild after code change | `docker compose build && docker compose up -d` |
| Shell into container | `docker compose exec respireeclaw bash` |
| Agent status | `docker compose exec respireeclaw node agent.js status` |
| Agent logs | `docker compose exec respireeclaw node agent.js logs` |

---

## Notes

- **Data persistence**: AURA config, SQLite memory, and logs are stored in the
  `aura_data` Docker volume — they survive container restarts and rebuilds.
- **AWS SDK credentials**: If your EC2 has an IAM instance role with the right
  permissions, the AWS SDK picks them up automatically — no extra env vars needed.
- **Playwright**: Chromium is installed in the image for web scraping skills.
  Remove the `playwright install` line in the Dockerfile if you don't need it
  (saves ~300 MB of image size).
