RespireeClaw Gateway
=====================

Installation
------------

1. Extract this zip file to a permanent location
2. Run the installer:
   - Windows: Double-click INSTALL.bat
   - macOS/Linux: bash INSTALL.sh

3. Follow the onboard wizard prompts

Quick Start
-----------

After installation:

    # Start the server
    node agent.js --daemon

    # Check status
    node agent.js status

    # View logs
    node agent.js logs

    # Stop the server
    node agent.js stop

Configuration
-------------

Configuration files are stored in ~/.aura/:
- config.yaml - Main settings
- agents.yaml - Agent definitions
- skills/ - Installed skills

Requirements
------------

- Node.js 20+
- npm

See README.md for full documentation.
